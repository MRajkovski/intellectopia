package io.flutter.plugins.firebaseauthexample

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
